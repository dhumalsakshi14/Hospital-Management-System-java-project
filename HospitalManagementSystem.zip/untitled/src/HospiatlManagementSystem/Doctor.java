package HospiatlManagementSystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import static java.lang.System.out;

public class Doctor {

    private Connection con;


    public Doctor(Connection con)
    {
        this.con=con;


    }


    public void veiwDoctor() {
        String query = "SELECT * FROM Doctors";

        try (PreparedStatement pst = con.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {

            System.out.println("Doctors:");
            System.out.println("+-------------+-----------+--------------+");
            System.out.printf("| %-11s | %-9s | %-12s |%n",
                    "Doctor ID", "Name", "Department");
            System.out.println("+-------------+-----------+--------------+");

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String dep = rs.getString("dep");

                System.out.printf("| %-11d | %-9s | %-12s |%n",
                        id, name, dep);
            }

            System.out.println("+-------------+-----------+--------------+");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean getDoctorById(int id) {
        String query = "select * from Doctors where id=?";

        try {
            PreparedStatement pst = con.prepareStatement(query);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();

        }
        return false;
    }
}
