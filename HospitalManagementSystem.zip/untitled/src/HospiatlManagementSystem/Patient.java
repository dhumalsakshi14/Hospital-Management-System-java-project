package HospiatlManagementSystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import static java.lang.System.*;

public class Patient {
    private Connection con;
    private Scanner scan;

    public Patient(Connection con,Scanner scan)
    {
        this.con=con;
        this.scan=scan;

    }
    public void addPatient()
    {
        out.println("Enter Name of Patient:-");
        String name=scan.next();

        out.println("Enter Age:-");
        int age= scan.nextInt();

        out.println("Enter Gender:-");
        String gen= scan.next();

        try {
            String query="insert into patients(name,age,gen)values(?,?,?)";
            PreparedStatement pst=con.prepareStatement(query);

            pst.setString(1,name);
            pst.setInt(2,age);
            pst.setString(3,gen);

            int affesctedRows=pst.executeUpdate();
            if (affesctedRows>0)
            {
                out.println("Patient added successfuly");
            }else {
                out.println("Failed to add Patient!!!!");
            }

        }catch(SQLException e)
        {
            e.printStackTrace();
        }
    }


    public void veiwPatient() {
        String query = "SELECT * FROM patients";

        try (PreparedStatement pst = con.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {

            System.out.println("Patients:");
            System.out.println("+--------------+----------------------+------------+--------------+");
            System.out.printf("| %-12s | %-20s | %-10s | %-12s |%n",
                    "Patient ID", "Name", "Age", "Gender");
            System.out.println("+--------------+----------------------+------------+--------------+");

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                int age = rs.getInt("age");
                String gen = rs.getString("gen");

                System.out.printf("| %-12d | %-20s | %-10d | %-12s |%n",
                        id, name, age, gen);
            }

            System.out.println("+--------------+----------------------+------------+--------------+");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean getPatientById(int id) {
        String query = "select * from patients where id=?";

        try {
            PreparedStatement pst = con.prepareStatement(query);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();

        }
        return false;
    }
}
