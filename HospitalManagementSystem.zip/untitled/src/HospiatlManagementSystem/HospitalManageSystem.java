
package HospiatlManagementSystem;

import java.sql.*;
import java.util.Scanner;

public class HospitalManageSystem {

    private static final String url =
            "jdbc:mysql://localhost:3306/Hospital";
    private static final String username = "root";
    private static final String password = "root";

    public static void main(String[] args) {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return;
        }

        Scanner scan = new Scanner(System.in);

        try (Connection con =
                     DriverManager.getConnection(url, username, password)) {

            Patient patient = new Patient(con, scan);
            Doctor doctor = new Doctor(con);

            while (true) {

                System.out.println("HOSPITAL MANAGEMENT SYSTEM");
                System.out.println("1. ADD PATIENTS");
                System.out.println("2. VIEW PATIENTS");
                System.out.println("3. VIEW DOCTORS");
                System.out.println("4. BOOK APPOINTMENT");
                System.out.println("5. EXIT");

                System.out.println("ENTER YOUR CHOICE");

                int choice = scan.nextInt();

                switch (choice) {

                    case 1:
                        patient.addPatient();
                        System.out.println();
                        break;

                    case 2:
                        patient.veiwPatient();
                        System.out.println();
                        break;

                    case 3:
                        doctor.veiwDoctor();
                        System.out.println();
                        break;

                    case 4:
                        bookAppointment(patient, doctor, con, scan);
                        System.out.println();
                        break;

                    case 5:
                        System.out.println("Exiting Hospital Management System...");
                        return;

                    default:
                        System.out.println("Enter Valid Choice");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            scan.close();
        }
    }

    public static void bookAppointment(
            Patient patient,
            Doctor doctor,
            Connection con,
            Scanner scan) {

        System.out.println("Enter Patient ID:");
        int patientId = scan.nextInt();

        System.out.println("Enter Doctor ID:");
        int doctorId = scan.nextInt();

        System.out.println("Enter Appointment Date (yyyy-mm-dd):");
        String appointmentDate = scan.next();

        if (patient.getPatientById(patientId)
                && doctor.getDoctorById(doctorId)) {

            if (checkDoctorAvailability(doctorId, appointmentDate, con)) {

                String appointQuery =
                        "INSERT INTO Appointments " +
                                "(patient_id, doctor_id, appointment_date) " +
                                "VALUES (?, ?, ?)";

                try (PreparedStatement pst =
                             con.prepareStatement(appointQuery)) {

                    pst.setInt(1, patientId);
                    pst.setInt(2, doctorId);
                    pst.setString(3, appointmentDate);

                    int rowsAffected = pst.executeUpdate();

                    if (rowsAffected > 0) {
                        System.out.println(
                                "Appointment Booked Successfully!");
                    } else {
                        System.out.println(
                                "Failed to Book Appointment!");
                    }

                } catch (SQLException e) {
                    e.printStackTrace();
                }

            } else {
                System.out.println(
                        "Doctor is not available on this date.");
            }

        } else {
            System.out.println(
                    "Either Patient or Doctor Does Not Exist.");
        }
    }

    public static boolean checkDoctorAvailability(
            int doctorId,
            String appointmentDate,
            Connection con) {

        String query =
                "SELECT COUNT(*) FROM Appointments " +
                        "WHERE doctor_id = ? AND appointment_date = ?";

        try (PreparedStatement pst = con.prepareStatement(query)) {

            pst.setInt(1, doctorId);
            pst.setString(2, appointmentDate);

            try (ResultSet rs = pst.executeQuery()) {

                if (rs.next()) {
                    int count = rs.getInt(1);

                    return count == 0;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
}
